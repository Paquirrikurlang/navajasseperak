<?php
/*
    //IP DEL SERVIDOR DE BASE DE DATOS
    define("DB_HOST","localhost");

    //NOMBRE DE LA BASE DE DATOS
    define("DB_NAME","dbsistema");

    //USUARIO DE LA BASE DE DATOS
    define("DB_USERNAME","root");

    //CONTRASEÑA DEL USUARIO DE LA BASE DE DATOS
    define("DB_PASSWORD","root");

    //CODIFICACION DE LOS CARACTERES
    define("DB_ENCODE","utf8");

    //CONSTANTE COMO NOMBRE DEL PROYECTO
    define("PRO_NOMBRE","ITVentas");
    */
        //IP DEL SERVIDOR DE BASE DE DATOS
        define("DB_HOST","aglobalsystems.com");

        //NOMBRE DE LA BASE DE DATOS
        define("DB_NAME","ags2007_ugpasociados");
    
        //USUARIO DE LA BASE DE DATOS
        define("DB_USERNAME","ags2007_usocios");
    
        //CONTRASEÑA DEL USUARIO DE LA BASE DE DATOS
        define("DB_PASSWORD","usocios");
    
        //CODIFICACION DE LOS CARACTERES
        define("DB_ENCODE","utf8");
    
        //CONSTANTE COMO NOMBRE DEL PROYECTO
        define("PRO_NOMBRE","ITVentas");

    
?>