<div class="pswp" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="pswp__bg"></div>
    <div class="pswp__scroll-wrap">
        <div class="pswp__container" style="transform: translate3d(0px, 0px, 0px);">
            <div class="pswp__item" style="display: block; transform: translate3d(-1441px, 0px, 0px);">
                <div class="pswp__zoom-wrap" style="transform: translate3d(339px, 44px, 0px) scale(1);"><img class="pswp__img" src="http://navajasseperak.com/images/navajas/spk.png" style="opacity: 1; width: 609px; height: 609px;"></div>
            </div>
            <div class="pswp__item" style="transform: translate3d(0px, 0px, 0px);">
                <div class="pswp__zoom-wrap" style="transform: translate3d(171px, 186.5px, 0px) scale(0.607553);"><img class="pswp__img pswp__img--placeholder" src="http://navajasseperak.com/images/navajas/colaDeRata.png" style="width: 236px; height: 236px; display: none;"><img class="pswp__img" src="http://navajasseperak.com/images/navajas/colaDeRata.png" style="display: block; width: 609px; height: 609px;"></div>
            </div>
            <div class="pswp__item" style="display: block; transform: translate3d(1441px, 0px, 0px);">
                <div class="pswp__zoom-wrap" style="transform: translate3d(339px, 44px, 0px) scale(1);"><img class="pswp__img" src="http://navajasseperak.com/images/navajas/filipina.png" style="opacity: 1; width: 609px; height: 609px;"></div>
            </div>
        </div>
        <div class="pswp__ui pswp__ui--fit pswp__ui--hidden">
            <div class="pswp__top-bar">
                <div class="pswp__counter">1 / 5</div><button class="pswp__button pswp__button--close" title="Close (Esc)"></button>
                <!--<button class="pswp__button pswp__button&#45;&#45;share" title="Share"></button>--> <button class="pswp__button pswp__button--fs" title="Toggle fullscreen"></button> <button class="pswp__button pswp__button--zoom" title="Zoom in/out"></button>
                <div class="pswp__preloader">
                    <div class="pswp__preloader__icn">
                        <div class="pswp__preloader__cut">
                            <div class="pswp__preloader__donut"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="pswp__share-modal pswp__share-modal--hidden pswp__single-tap">
                <div class="pswp__share-tooltip"></div>
            </div><button class="pswp__button pswp__button--arrow--left" title="Previous (arrow left)"></button> <button class="pswp__button pswp__button--arrow--right" title="Next (arrow right)"></button>
            <div class="pswp__caption">
                <div class="pswp__caption__center"></div>
            </div>
        </div>
    </div>
</div><!-- photoswipe / end -->